<?php

include('master/Examination.php');

$exam = new Examination;
include('header.php');
?>
<body>

<?php


date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$timestamp = date('d-m-Y H:i:s');

header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

?>
<!-- Image and text -->

<div class="container">
    <div class="row" style="margin-top:50px;">
                    <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">

                <form method="post" action="pgRedirect.php">

                        <div class="row">
                            <div class="col-xs-6 col-sm-6 col-md-6">
                                <address>
                                <strong><?php echo $_SESSION['username']; ?></strong>
                                <br>                                
                            </address>
                        </div>
                        <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                            <p>
                                <em>Date: <?php echo date("jS F, Y", strtotime($timestamp)); ?></em>
                            </p>
                            <p>
                                <em>ORDER-ID #: <input id="ORDER_ID" tabindex="1" maxlength="20" size="11" style="border: none;background: #f5f5f5" 
                                                                        name="ORDER_ID" autocomplete="off"
                                                                        value="<?php echo  "ORDS" . rand(10000,99999999)?>"></em>
                            </p>
                              <p>
                                <em>CUST-ID #: <input id="CUST_ID" tabindex="1" maxlength="20" size="11" style="border: none;background: #f5f5f5" 
                                                                        name="CUST_ID" autocomplete="off"
                                                                        value="<?php echo  "CUST" . rand(10000,99999999)?>"></em>
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="text-center">
                            <h1>College Fee Payment</h1>
                        </div>
                        </span>
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Terms</th>
                                    <th class="text-center">Fee</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="col-md-9"><em>Tution</em></h4></td>
                                    <td class="col-md-1 text-center">Rs.100</td>
                                </tr>
                                <tr>
                                    <td class="col-md-9"><em>Lab</em></h4></td>
                                    <td class="col-md-1 text-center">Rs.10</td>
                                </tr>
                                <tr>
                                    <td class="col-md-9"><em>Book</em></h4></td>
                                    <td class="col-md-1 text-center">Rs.20</td>
                                </tr>
                                <tr>
                                    <td><input type="hidden" id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail">   </td>
                                    <td><input type="hidden" id="CHANNEL_ID" tabindex="4" maxlength="12" size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">  </td>

                                    <td class="text-right"><h4><strong>Total: </strong></h4></td>
                                    <td class="text-center text-danger">
                                        <h4><strong><input title="TXN_AMOUNT" tabindex="10" type="text" name="TXN_AMOUNT" value="130" size="3" style="border: none;background: #f5f5f5" ></strong></h4>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <button type="submit" value="CheckOut"  class="btn btn-success btn-lg btn-block">
                            Pay Now   <span class="glyphicon glyphicon-chevron-right"></span>
                        </button></td>
                    </div>
</form>
                </div>
    


    </div>
    </body>