 <center> 
        <nav class="navbar">
          <a class="navbar-brand " href="fee.php">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Paytm_logo.jpg" width="100" height="30" class="d-inline-block align-top" alt="">
             Payment Intigration 
          </a>
        </nav>
    </center>
