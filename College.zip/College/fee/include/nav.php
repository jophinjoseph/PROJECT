 <center> 
        <nav class="navbar">
          <a class="navbar-brand " href="kart.php">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/cd/Paytm_logo.jpg" width="100" height="30" class="d-inline-block align-top" alt="">
             Payment Intigration 
          </a>
           <ul class="nav navbar-nav navbar-right">
           	  <li> <a href="https://youtu.be/gvpShOeYd5k"> <strong><i class="fab fa-youtube text-danger" ></i> Video Demo</strong></a></li>
		      <li> <a href="https://www.youtube.com/channel/UCVlSbZdK_7tTF_X91gpD48g?view_as=subscriber"> <strong><i class="fab fa-youtube text-danger" ></i> Codelone</strong></a></li>
			  <li><a href="https://instagram.com/code_lone/"> <strong><i class="fab fa-instagram text-default" ></i> instagram.com</a></li>
		    </ul>
        </nav>
    </center>
